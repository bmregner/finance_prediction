## How to run this code
----
Hello, congratulations on extracting this folder from the archive, you're in good shape.

1) cd into the finance_learning_tool/ directory

2) type and run in the command line
```
python3 guess_sp500_tool.py
```
3) sit back and enjoy, but be aware that the first time you use this, there will be quite a lot of downloading happening

## Requirements
---
Hmm let's see... python 3 and a bunch of modules thereof, including gensim, nltk, scikit-learn, pandas, and many others. 

N.B. For now the code will just throw an error and complain about the missing modules, please be sure to install them properly (i.e. in the same environment as your python3 is run in, if you're using anaconda)
